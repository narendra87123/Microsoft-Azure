package com.example.careeradvisor;

import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class CareerAdvisorController {

    @PostMapping("/career-advice")
    public Map<String, String> getCareerAdvice(@RequestBody Map<String, String> payload) {
        String skills = payload.get("skills");
        String advice = "Based on your skills in " + skills + ", we suggest exploring Software Engineering or Data Science.";
        return Map.of("advice", advice);
    }
}