package com.example.careeradvisor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerAdvisorApplication {
    public static void main(String[] args) {
        SpringApplication.run(CareerAdvisorApplication.class, args);
    }
}